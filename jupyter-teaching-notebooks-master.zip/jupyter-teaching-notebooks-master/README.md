# Jupyter teaching notebooks
This repository contains used for teaching by [Ian McLoughlin](https://ianmcloughlin.github.io), a Lecturer at [GMIT](http://wwww.gmit.ie).
